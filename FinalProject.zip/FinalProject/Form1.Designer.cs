﻿namespace FinalProject
{
    partial class ConversionCalculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            cupsLabel = new Label();
            tbsLabel = new Label();
            tspsLabel = new Label();
            batchLabel = new Label();
            cupsOutLabel = new Label();
            tbsOutLabel = new Label();
            tspsOutLabel = new Label();
            ouncesLabel = new Label();
            gramsLabel = new Label();
            batchWeightLabel = new Label();
            ouncesOutLabel = new Label();
            gramsOutLabel = new Label();
            cupsIn = new TextBox();
            tbsIn = new TextBox();
            tspsIn = new TextBox();
            batchVolume = new TextBox();
            convertVolume = new Button();
            convertWeight = new Button();
            ouncesIn = new TextBox();
            gramsIn = new TextBox();
            batchWeight = new TextBox();
            substText = new Label();
            cupsOut = new Label();
            tbsOut = new Label();
            tspsOut = new Label();
            ouncesOut = new Label();
            gramsOut = new Label();
            substBox = new TextBox();
            confirmButton = new Button();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Font = new Font("Wide Latin", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            titleLabel.Location = new Point(64, 9);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(396, 24);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Conversion Calculator";
            // 
            // cupsLabel
            // 
            cupsLabel.AutoSize = true;
            cupsLabel.Location = new Point(30, 73);
            cupsLabel.Name = "cupsLabel";
            cupsLabel.Size = new Size(41, 20);
            cupsLabel.TabIndex = 1;
            cupsLabel.Text = "Cups";
            // 
            // tbsLabel
            // 
            tbsLabel.AutoSize = true;
            tbsLabel.Location = new Point(30, 120);
            tbsLabel.Name = "tbsLabel";
            tbsLabel.Size = new Size(91, 20);
            tbsLabel.TabIndex = 2;
            tbsLabel.Text = "Tablespoons";
            // 
            // tspsLabel
            // 
            tspsLabel.AutoSize = true;
            tspsLabel.Location = new Point(30, 169);
            tspsLabel.Name = "tspsLabel";
            tspsLabel.Size = new Size(79, 20);
            tspsLabel.TabIndex = 3;
            tspsLabel.Text = "Teaspoons";
            // 
            // batchLabel
            // 
            batchLabel.AutoSize = true;
            batchLabel.Location = new Point(30, 219);
            batchLabel.Name = "batchLabel";
            batchLabel.Size = new Size(77, 20);
            batchLabel.TabIndex = 4;
            batchLabel.Text = "Batch Size";
            // 
            // cupsOutLabel
            // 
            cupsOutLabel.AutoSize = true;
            cupsOutLabel.Location = new Point(30, 325);
            cupsOutLabel.Name = "cupsOutLabel";
            cupsOutLabel.Size = new Size(41, 20);
            cupsOutLabel.TabIndex = 5;
            cupsOutLabel.Text = "Cups";
            // 
            // tbsOutLabel
            // 
            tbsOutLabel.AutoSize = true;
            tbsOutLabel.Location = new Point(30, 367);
            tbsOutLabel.Name = "tbsOutLabel";
            tbsOutLabel.Size = new Size(91, 20);
            tbsOutLabel.TabIndex = 6;
            tbsOutLabel.Text = "Tablespoons";
            // 
            // tspsOutLabel
            // 
            tspsOutLabel.AutoSize = true;
            tspsOutLabel.Location = new Point(30, 410);
            tspsOutLabel.Name = "tspsOutLabel";
            tspsOutLabel.Size = new Size(79, 20);
            tspsOutLabel.TabIndex = 7;
            tspsOutLabel.Text = "Teaspoons";
            // 
            // ouncesLabel
            // 
            ouncesLabel.AutoSize = true;
            ouncesLabel.Location = new Point(300, 73);
            ouncesLabel.Name = "ouncesLabel";
            ouncesLabel.Size = new Size(57, 20);
            ouncesLabel.TabIndex = 8;
            ouncesLabel.Text = "Ounces";
            // 
            // gramsLabel
            // 
            gramsLabel.AutoSize = true;
            gramsLabel.Location = new Point(494, 73);
            gramsLabel.Name = "gramsLabel";
            gramsLabel.Size = new Size(51, 20);
            gramsLabel.TabIndex = 9;
            gramsLabel.Text = "Grams";
            // 
            // batchWeightLabel
            // 
            batchWeightLabel.AutoSize = true;
            batchWeightLabel.Location = new Point(380, 120);
            batchWeightLabel.Name = "batchWeightLabel";
            batchWeightLabel.Size = new Size(77, 20);
            batchWeightLabel.TabIndex = 10;
            batchWeightLabel.Text = "Batch Size";
            // 
            // ouncesOutLabel
            // 
            ouncesOutLabel.AutoSize = true;
            ouncesOutLabel.Location = new Point(300, 203);
            ouncesOutLabel.Name = "ouncesOutLabel";
            ouncesOutLabel.Size = new Size(57, 20);
            ouncesOutLabel.TabIndex = 11;
            ouncesOutLabel.Text = "Ounces";
            // 
            // gramsOutLabel
            // 
            gramsOutLabel.AutoSize = true;
            gramsOutLabel.Location = new Point(494, 203);
            gramsOutLabel.Name = "gramsOutLabel";
            gramsOutLabel.Size = new Size(51, 20);
            gramsOutLabel.TabIndex = 12;
            gramsOutLabel.Text = "Grams";
            // 
            // cupsIn
            // 
            cupsIn.Location = new Point(126, 70);
            cupsIn.Name = "cupsIn";
            cupsIn.Size = new Size(125, 27);
            cupsIn.TabIndex = 13;
            // 
            // tbsIn
            // 
            tbsIn.Location = new Point(126, 117);
            tbsIn.Name = "tbsIn";
            tbsIn.Size = new Size(125, 27);
            tbsIn.TabIndex = 14;
            // 
            // tspsIn
            // 
            tspsIn.Location = new Point(126, 166);
            tspsIn.Name = "tspsIn";
            tspsIn.Size = new Size(125, 27);
            tspsIn.TabIndex = 15;
            // 
            // batchVolume
            // 
            batchVolume.Location = new Point(126, 216);
            batchVolume.Name = "batchVolume";
            batchVolume.Size = new Size(125, 27);
            batchVolume.TabIndex = 16;
            // 
            // convertVolume
            // 
            convertVolume.BackColor = Color.Linen;
            convertVolume.ForeColor = Color.DarkGoldenrod;
            convertVolume.Location = new Point(94, 269);
            convertVolume.Name = "convertVolume";
            convertVolume.Size = new Size(94, 29);
            convertVolume.TabIndex = 20;
            convertVolume.Text = "Convert";
            convertVolume.UseVisualStyleBackColor = false;
            convertVolume.Click += ConvertVolume_Click;
            // 
            // convertWeight
            // 
            convertWeight.BackColor = Color.Linen;
            convertWeight.ForeColor = Color.DarkGoldenrod;
            convertWeight.Location = new Point(451, 160);
            convertWeight.Name = "convertWeight";
            convertWeight.Size = new Size(94, 29);
            convertWeight.TabIndex = 21;
            convertWeight.Text = "Convert";
            convertWeight.UseVisualStyleBackColor = false;
            convertWeight.Click += ConvertWeight_Click;
            // 
            // ouncesIn
            // 
            ouncesIn.Location = new Point(363, 70);
            ouncesIn.Name = "ouncesIn";
            ouncesIn.Size = new Size(125, 27);
            ouncesIn.TabIndex = 22;
            // 
            // gramsIn
            // 
            gramsIn.Location = new Point(551, 70);
            gramsIn.Name = "gramsIn";
            gramsIn.Size = new Size(125, 27);
            gramsIn.TabIndex = 23;
            // 
            // batchWeight
            // 
            batchWeight.Location = new Point(463, 115);
            batchWeight.Name = "batchWeight";
            batchWeight.Size = new Size(125, 27);
            batchWeight.TabIndex = 24;
            // 
            // substText
            // 
            substText.BackColor = Color.Linen;
            substText.BorderStyle = BorderStyle.Fixed3D;
            substText.ForeColor = Color.DarkGoldenrod;
            substText.Location = new Point(696, 160);
            substText.Name = "substText";
            substText.Size = new Size(299, 326);
            substText.TabIndex = 28;
            substText.Text = "Type 'Help' in the textbox above for a list of valid keywords.";
            // 
            // cupsOut
            // 
            cupsOut.BorderStyle = BorderStyle.Fixed3D;
            cupsOut.Location = new Point(126, 325);
            cupsOut.Name = "cupsOut";
            cupsOut.Size = new Size(125, 25);
            cupsOut.TabIndex = 29;
            // 
            // tbsOut
            // 
            tbsOut.BorderStyle = BorderStyle.Fixed3D;
            tbsOut.Location = new Point(126, 367);
            tbsOut.Name = "tbsOut";
            tbsOut.Size = new Size(125, 25);
            tbsOut.TabIndex = 30;
            // 
            // tspsOut
            // 
            tspsOut.BorderStyle = BorderStyle.Fixed3D;
            tspsOut.Location = new Point(126, 410);
            tspsOut.Name = "tspsOut";
            tspsOut.Size = new Size(125, 25);
            tspsOut.TabIndex = 31;
            // 
            // ouncesOut
            // 
            ouncesOut.BorderStyle = BorderStyle.Fixed3D;
            ouncesOut.Location = new Point(363, 202);
            ouncesOut.Name = "ouncesOut";
            ouncesOut.Size = new Size(125, 25);
            ouncesOut.TabIndex = 32;
            // 
            // gramsOut
            // 
            gramsOut.BorderStyle = BorderStyle.Fixed3D;
            gramsOut.Location = new Point(551, 202);
            gramsOut.Name = "gramsOut";
            gramsOut.Size = new Size(125, 25);
            gramsOut.TabIndex = 33;
            // 
            // substBox
            // 
            substBox.Location = new Point(745, 70);
            substBox.Name = "substBox";
            substBox.Size = new Size(203, 27);
            substBox.TabIndex = 34;
            // 
            // confirmButton
            // 
            confirmButton.BackColor = Color.Linen;
            confirmButton.ForeColor = Color.DarkGoldenrod;
            confirmButton.Location = new Point(802, 115);
            confirmButton.Name = "confirmButton";
            confirmButton.Size = new Size(94, 29);
            confirmButton.TabIndex = 35;
            confirmButton.Text = "Confirm";
            confirmButton.UseVisualStyleBackColor = false;
            confirmButton.Click += ConfirmButton_Click;
            // 
            // ConversionCalculator
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Tan;
            ClientSize = new Size(1021, 515);
            Controls.Add(confirmButton);
            Controls.Add(substBox);
            Controls.Add(gramsOut);
            Controls.Add(ouncesOut);
            Controls.Add(tspsOut);
            Controls.Add(tbsOut);
            Controls.Add(cupsOut);
            Controls.Add(substText);
            Controls.Add(batchWeight);
            Controls.Add(gramsIn);
            Controls.Add(ouncesIn);
            Controls.Add(convertWeight);
            Controls.Add(convertVolume);
            Controls.Add(batchVolume);
            Controls.Add(tspsIn);
            Controls.Add(tbsIn);
            Controls.Add(cupsIn);
            Controls.Add(gramsOutLabel);
            Controls.Add(ouncesOutLabel);
            Controls.Add(batchWeightLabel);
            Controls.Add(gramsLabel);
            Controls.Add(ouncesLabel);
            Controls.Add(tspsOutLabel);
            Controls.Add(tbsOutLabel);
            Controls.Add(cupsOutLabel);
            Controls.Add(batchLabel);
            Controls.Add(tspsLabel);
            Controls.Add(tbsLabel);
            Controls.Add(cupsLabel);
            Controls.Add(titleLabel);
            ForeColor = Color.Linen;
            Name = "ConversionCalculator";
            Text = "Conversion Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private Label cupsLabel;
        private Label tbsLabel;
        private Label tspsLabel;
        private Label batchLabel;
        private Label cupsOutLabel;
        private Label tbsOutLabel;
        private Label tspsOutLabel;
        private Label ouncesLabel;
        private Label gramsLabel;
        private Label batchWeightLabel;
        private Label ouncesOutLabel;
        private Label gramsOutLabel;
        private TextBox cupsIn;
        private TextBox tbsIn;
        private TextBox tspsIn;
        private TextBox batchVolume;
        private Button convertVolume;
        private Button convertWeight;
        private TextBox ouncesIn;
        private TextBox gramsIn;
        private TextBox batchWeight;
        private Label substText;
        private Label cupsOut;
        private Label tbsOut;
        private Label tspsOut;
        private Label ouncesOut;
        private Label gramsOut;
        private TextBox substBox;
        private Button confirmButton;
    }
}
