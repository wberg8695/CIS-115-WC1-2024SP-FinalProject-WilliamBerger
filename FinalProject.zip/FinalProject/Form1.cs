using System.Diagnostics.Eventing.Reader;

namespace FinalProject
{
    public partial class ConversionCalculator : Form
    {
        public ConversionCalculator()
        {
            InitializeComponent();
        }
        private void ConvertVolume_Click(object sender, EventArgs e)
        {
            double[] outputArray = FinalVolumeCalc();
            cupsOut.Text = Convert.ToString(outputArray[0]);
            tbsOut.Text = Convert.ToString(outputArray[1]);
            tspsOut.Text = Convert.ToString(outputArray[2]);
        }
        //The Cups method calculates the cups value based on the batch size
        private double[] Cups()
        {
            double cupsVal = Convert.ToDouble(cupsIn.Text);
            double batchVal1 = Convert.ToDouble(batchVolume.Text);
            double cups1, tbs1, tsps1;
            cups1 = cupsVal * batchVal1;
            tbs1 = 0;
            tsps1 = 0;
            // 0.0625 cups = 1 tablespoon
            if (cups1 < .25 && cups1 >= 0.0625)
            {
                for (double x = cups1; x >= 0.0625; x = x - .0625)
                {
                    cups1 = cups1 - .0625;
                    tbs1 = tbs1 + 1;
                }
            }
            //0,0208 cups = 1 teaspoon
            if (cups1 < 0.0625 && cups1 >= 0.0208)
            {
                for (double y = .0625; y >= .0208; y = y - .0208)
                {
                    cups1 = cups1 - .0208;
                    tsps1 = tsps1 + 1;
                }
            }
            //There are 48 teaspoons in 1 cup, anything smaller than this is unnecessary
            if (cups1 < 0.0208)
            {
                cups1 = 0;
            }
            double[] values1 = { cups1, tbs1, tsps1 };
            return values1;
        }
        //The Tablespoons method calculates the tablespoons value based on the batch size
        private double[] Tablespoons()
        {
            double tbsVal = Convert.ToDouble(tbsIn.Text);
            double batchVal2 = Convert.ToDouble(batchVolume.Text);
            double cups2, tbs2, tsps2;
            tbs2 = tbsVal * batchVal2;
            cups2 = 0;
            tsps2 = 0;
            //4 tablespoons = 1/4 cup
            if (tbs2 > 4)
            {
                for (double z = tbs2; z >= 4; z = z - 4)
                {
                    tbs2 = tbs2 - 4;
                    cups2 = cups2 + .25;
                }
            }
            //0.0416 tablespoons = 1/8 teaspoon
            if (tbs2 < 0.5 && tbs2 >= 0.0416)
            {
                for (double a = tbs2; a >= 0.0416; a = a - 0.0416)
                {
                    tbs2 = tbs2 - 0.0416;
                    tsps2 = tsps2 + 0.125;
                }
            }
            //Anything smaller than 1/8 teaspoon is unnecessary
            //The difference is too small to notice when cooking/baking
            if (tbs2 < 0.0416)
            {
                tbs2 = 0;
            }
            double[] values2 = { cups2, tbs2, tsps2 };
            return values2;
        }
        //The Teaspoons method calculates the teaspoons value base on the batch size
        private double[] Teaspoons()
        {
            double tspsVal = Convert.ToDouble(tspsIn.Text);
            double batchVal3 = Convert.ToDouble(batchVolume.Text);
            double cups3, tbs3, tsps3;
            tsps3 = tspsVal * batchVal3;
            cups3 = 0;
            tbs3 = 0;
            //12 teaspoons = 1/4 cup
            if (tsps3 >= 12)
            {
                for (double b = tsps3; b >= 12; b = b - 12)
                {
                    tsps3 = tsps3 - 12;
                    cups3 = cups3 + .25;
                }
            }
            //3 teaspoons = 1 tablespoon
            if (tsps3 < 12 && tsps3 >= 3)
            {
                for (double c = tsps3; c >= 3; c = c - 3)
                {
                    tsps3 = tsps3 - 3;
                    tbs3 = tbs3 + 1;
                }
            }
            double[] values3 = { cups3, tbs3, tsps3 };
            return values3;
        }
        //The FinalVolumeCalc method adds together the cups, tablespoons, and teaspoons
        //values from the Cups, Tablespoons, and Teaspoons methods
        private double[] FinalVolumeCalc()
        {
            double finalCups, finalTbs, finalTsps;
            double[] array1 = Cups();
            double[] array2 = Tablespoons();
            double[] array3 = Teaspoons();
            finalCups = array1[0] + array2[0] + array3[0];
            finalTbs = array1[1] + array2[1] + array3[1];
            finalTsps = array1[2] + array2[2] + array3[2];
            double[] finalArray = { finalCups, finalTbs, finalTsps };
            return finalArray;
        }
        private void ConvertWeight_Click(object sender, EventArgs e)
        {
            double ounces, grams, ouncesMath, gramsMath, batch;
            ounces = Convert.ToDouble(ouncesIn.Text);
            grams = Convert.ToDouble(gramsIn.Text);
            batch = Convert.ToDouble(batchWeight.Text);
            ouncesMath = grams / 28.35;
            gramsMath = ounces * 28.35;
            if (ounces > 0)
            {
                ouncesOut.Text = Convert.ToString(ounces * batch);
                gramsOut.Text = Convert.ToString(gramsMath * batch);
            }
            if (grams > 0)
            {
                ouncesOut.Text = Convert.ToString(ouncesMath * batch);
                gramsOut.Text = Convert.ToString(grams * batch);
            }
        }
        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            if (substBox.Text == "Help")
            {
                //List of available keywords
                substText.Text = "-Baking Powder \n-Baking Soda \n-Bread Crumbs \n-Broth \n" +
                    "-Brown Sugar \n-Butter \n-Buttermilk \n-Cocoa Powder \n-Heavy Whipping Cream " +
                    "\n-Egg \n-Bread Flour \n-Cake Flour \n-Self Rising Flour \n" +
                    "-Whole Milk \n-Vegetable Oil \n-White Sugar";
            }
            else
            {
                if (substBox.Text == "Baking Powder")
                {
                    substText.Text = "1 tsp = 1/4 teaspoon baking soda + " +
                        "1/2 teaspoon cream of tartar OR 1/4 teaspoon baking soda + " +
                        "1/2 cup buttermilk (decrease liquid in recipe by 1/2 cup)";
                }
                else
                {
                    if (substBox.Text == "Baking Soda")
                    {
                        substText.Text = "1 tsp = 4 tsps baking powder";
                    }
                    else
                    {
                        if (substBox.Text == "Bread Crumbs")
                        {
                            substText.Text = "1 cup = 1 cup cracker crumbs OR 1 cup ground oats";
                        }
                        else
                        {
                            if (substBox.Text == "Broth")
                            {
                                substText.Text = "1 cup = 1 bouillon cube + 1 cup boiling water " +
                                    "OR 1 tablespoon soy sauce + enough water to make 1 cup " +
                                    "OR 1 cup vegetable broth";
                            }
                            else
                            {
                                if (substBox.Text == "Brown Sugar")
                                {
                                    substText.Text = "1 cup = 1 cup white sugar + 1/4 cup molasses " +
                                        "and decrease the liquid in recipe by 1/4 cup " +
                                        "OR 1 cup white sugar OR 1 1/4 cups confectioners' sugar";
                                }
                                else
                                {
                                    if (substBox.Text == "Butter")
                                    {
                                        substText.Text = "1 cup (Salted) = 1 cup margarine " +
                                            "OR 1 cup shortening + 1/2 teaspoon salt OR 7/8 cup vegetable oil + " +
                                            "1/2 teaspoon salt OR 7/8 cup lard plus 1/2 teaspoon salt \n" +
                                            "1 cup (Unsalted) = 1 cup shortening OR 7/8 cup vegetable oil " +
                                            "OR 7/8 cup lard";
                                    }
                                    else
                                    {
                                        if (substBox.Text == "Buttermilk")
                                        {
                                            substText.Text = "1 cup = 1 cup yogurt OR 1 tablespoon lemon juice or vinegar + " +
                                                "enough milk to make 1 cup";
                                        }
                                        else
                                        {
                                            if (substBox.Text == "Cocoa Powder")
                                            {
                                                substText.Text = "1/4 cup = 1 ounce unsweetened chocolate";
                                            }
                                            else
                                            {
                                                if (substBox.Text == "Heavy Whipping Cream")
                                                {
                                                    substText.Text = "1 cup = 1 cup evaporated milk OR 3/4 cup milk + " +
                                                        "1/3 cup butter";
                                                }
                                                else
                                                {
                                                    if (substBox.Text == "Egg")
                                                    {
                                                        substText.Text = "1 Egg 1 1/2 tablespoons vegetable oil + " +
                                                            "1 teaspoon baking powder + 1 1/2 tablespoons water " +
                                                            "OR 1 tablespoon distilled white vinegar or apple cider vinegar + " +
                                                            "1 teaspoon baking soda";
                                                    }
                                                    else
                                                    {
                                                        if (substBox.Text == "Bread Flour")
                                                        {
                                                            substText.Text = "1 cup = 1 cup all-purpose flour + 1 teaspoon wheat gluten";
                                                        }
                                                        else
                                                        {
                                                            if (substBox.Text == "Cake Flour")
                                                            {
                                                                substText.Text = "1 cup = 1 cup all-purpose flour - 2 tablespoons";
                                                            }
                                                            else
                                                            {
                                                                if (substBox.Text == "Self Rising Flour")
                                                                {
                                                                    substText.Text = "1 cup = 7/8 cup all-purpose flour + 1 1/2 teaspoons " +
                                                                        "baking powder + 1/2 teaspoon salt";
                                                                }
                                                                else
                                                                {
                                                                    if (substBox.Text == "Whole Milk")
                                                                    {
                                                                        substText.Text = "1 cup = 1 cup soy milk OR 1 cup rice milk " +
                                                                            "OR 1 cup water or juice OR 1/4 cup dry milk powder + " +
                                                                            "1 cup water OR 2/3 cup evaporated milk + 1/3 cup water";
                                                                    }
                                                                    else
                                                                    {
                                                                        if (substBox.Text == "Vegetable Oil")
                                                                        {
                                                                            substText.Text = "1 cup (For Baking) = 1 cup applesauce \n" +
                                                                                "1 cup (For Frying) = 1 cup lard OR 1 cup vegetable shortening";
                                                                        }
                                                                        else
                                                                        {
                                                                            if (substBox.Text == "White Sugar")
                                                                            {
                                                                                substText.Text = "1 cup brown sugar OR 1 1/4 cups confectioners' sugar " +
                                                                                    "OR 3/4 cup honey OR 3/4 cup corn syrup";
                                                                            }
                                                                            else
                                                                            {
                                                                                substText.Text = "That is not a valid keyword. \nType 'Help' in the textbox above " +
                                                                                    "for a list of valid keywords.";
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
